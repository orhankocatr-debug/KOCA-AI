# KOCA-AI

Experimental basic face-overlay video backend, **not** a realistic AI face-swap model.

## Render setup
- Create a Render **Web Service** from this GitHub repository.
- Runtime: Python, Build command: `pip install -r requirements.txt`
- Start command: `uvicorn app:app --host 0.0.0.0 --port $PORT`
- Instance: Free, if offered.
- Test `https://YOUR-RENDER-URL/health`.

## API
POST `/swap` with multipart fields `photo` (image) and `video` (MP4). Response is a silent MP4 video. Max video duration 10 seconds, max resolution 720p, max video 35MB, max image 8MB. Detection works best for frontal faces. Uploaded images and videos are processed on the server; temporary files are not automatically purged in this starter and must be cleaned up before public launch.

**Security/privacy:** Only use images with permission. This demo is not production-ready: add authentication, rate limiting, job cleanup, moderation, and a privacy notice. Change `ALLOWED_ORIGINS` to the precise origin of your KOCA site. The server does not preserve audio. Free CPU resources may not be sufficient for high traffic.
